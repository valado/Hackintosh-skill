# 02 硬件分流与安装路线

## 必须得到的现场资料

CPU 厂商／型号／架构／核心线程、主板与 BIOS、UEFI 或 Legacy、GPU 精确 PCI ID、显示器接在哪个接口、各网卡 PCI／USB ID、音频控制器与编解码器、存储型号和控制方式、全部物理磁盘及分区、加密状态、Secure Boot 状态。笔记本另查内外屏连接、MUX、触控板、键盘、电池与 Wi-Fi 是否可更换。

`collect-windows.ps1` 是基础采集，不保证完成 ACPI 导出、显示布线判断或物理 USB 映射。缺失项通过原作者工具、设备管理器或用户拍照补齐。网卡／音频只看商品名不够；Windows 驱动名也不是 macOS 驱动证据。

## 判断顺序

1. 识别平台：普通 x86-64 PC、ARM Windows PC、真正的 Mac、虚拟机不能共用同一路线。v0.1 的 PC 安装执行路线是 x86-64 UEFI；其他平台先研究专门支持，不能写入本路线的介质或承诺兼容。Legacy／MBR 转换另立方案，不能顺手转换系统盘。
2. 根据用途与关键硬件选择 macOS，而非默认“最新版”。核对 CPU、GPU 加速、存储与安装网络都存在可实施路线。恢复镜像的版本与安装器最终下载的版本可能不同，分别记录。
3. 每个设备标记：已有稳定支持／条件支持／实验性支持／无已知可用支持／证据不足。每项附来源、版本或提交、查阅日期和预计限制。开源 Windows／Linux 驱动不是可直接安装的 macOS kext。
4. 先给用户可行性摘要及方案。不兼容的必要设备不能留到抹盘后才说明。可选择更适合的系统版本、临时有线／USB 网卡、独立安装盘、替换硬件，或结束安装尝试。

## 分支路线

| 平台／设备 | 需要核对的差异 |
|---|---|
| Intel 台式机 | 按 CPU 代际、芯片组和目标系统选择 ACPI、CPU 识别、电源管理、核显方案；混合架构不能直接照搬旧代际参数 |
| AMD 台式机 | 读取 AMD-OSX 当前内核补丁说明，核对 OS 内核范围与核心数相关参数；明确软件兼容性限制，不能套 Intel CPU 补丁 |
| Intel／AMD 笔记本 | CPU 路线以外，必须确认屏幕布线、核显、独显切换和输入设备；无可驱动的显示输出时先停止安装路线 |
| Intel 传统核显／AMD 显卡 | 对照精确设备 ID 与 OS 支持，选择原生驱动／适配补丁；WhateverGreen 不提供所有新 Intel GPU 的底层驱动 |
| Intel Xe-LP 候选 | 按物理 PCI ID 查 [WhateverXe＋Graphics 分支](14-xe-lp.md)，含反馈的 8086:A7A0；后端覆盖、社区案例和本轮实测分开，不能套到所有 Xe／Arc 架构 |
| 新 NVIDIA 路线 | 先看 NullMoth 的 README、CARD-SUPPORT、版本说明与已知问题。支持列表和实机验收分开；不可套用旧 Web Driver，也不能承诺所有 RTX 笔记本内屏可用 |
| Wi-Fi／蓝牙 | 区分 Wi-Fi PCI 功能与蓝牙 USB 功能，核对系统版本、所需依赖和接力限制；保留一条已验证的网络通道 |
| NVMe／SATA／VMD／RAID | 确认安装盘可由 macOS 访问；切换 BIOS 存储模式可能破坏现有 Windows 启动，须先设计 Windows 适配与回退 |

不要将 Dortania 某个年代的支持表视为永不更新的结论。对新硬件结合项目原作者说明和可复核的运行证据；有冲突时记为未知，继续收集证据。

尤其不能在 00 接入阶段仅凭“较新的 NVIDIA RTX”就断言“加速基本无解／只能很卡”。先读取当前 [NullMoth 支持与验证说明](https://github.com/nullmoth/nvidia-macos-driver/blob/main/docs/CARD-SUPPORT.md)，区分设备表覆盖、作者实机验证、用户案例与本次实测；实验性不等于没有图形加速。与案例硬件相符时参考 [14700K＋4070 Ti SUPER](case-14700k-4070ti-super.md) 的历史图形检查和已知黑块／睡眠限制，但不能反过来保证此次重装必然稳定。

## 生成 EFI 前的专项准备

- 按 [阶段 03 的固定采集路线](04-installer.md)在 A 的 Windows 中导出 ACPI 原始表，默认由 Agent 准备 Python；A 缺少 Python 不是直接要求重启的理由。使用 SSDTTime 等原作者工具按本机生成必要补丁。已经可用的补丁仍核对设备路径，不把别人的 DSDT 作为默认输入。
- 在 Windows 阶段尽量完成 USBToolBox 端口发现与映射。用户需要逐孔插拔 USB 2／USB 3 设备，内部蓝牙按内部端口处理；工具输出后检查端口数量、连接类型和实际插孔覆盖。不能从“当前插着的设备”宣称全部 USB 已映射。
- 为网络准备至少一条安装恢复环境中可用的路径。恢复模式依赖下载时，仅在 Windows 中网卡可用并不足够。
- 选择合适 SMBIOS，生成本机独立身份或在修复现有系统时保留原有正确身份。新安装不复制案例的序列号、MLB、ROM 或 SystemUUID，也不借用真实 Mac 的身份。
- 保存 BIOS 当前设置与 BitLocker 恢复手段。不要批量关闭 TPM、Secure Boot、VT-d 或更改 AHCI/VMD；每项变化都应对应实际路线，考虑保留 Windows 的影响。

入口见 [sources.md](sources.md)：OpenCore 原始文档、AMD-OSX、SSDTTime、USBToolBox 与各驱动仓库。
