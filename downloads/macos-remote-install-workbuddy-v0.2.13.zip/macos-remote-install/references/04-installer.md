# 04 下载、组装 EFI 与制作安装介质

## GitHub 下载不通时怎么继续

这条规则也用于驱动和工具。先锁定仓库、tag／提交、准确文件名和预期大小，保存发布方给出的签名或摘要。相同版本、可重新核验的本地缓存可直接复用。安装 Skill 本身时，如 B 无法克隆，可使用用户取得的同一固定版本源码包，并核对来源及随包校验信息。

| 现场情况 | Agent 的下一步 |
|---|---|
| 能接通 GitHub 首页或 API，资产下载却超时 | 在准备下载的那台电脑对**具体文件**做限时 GET，允许 HTTPS 重定向，核对最终状态和实际收到的字节。发行页、源码 raw 文件、API 元数据与 Release 附件可能走不同路径。可用官方资产 API 请求二进制并跟随重定向，检查返回内容，避免把 JSON 或 HTML 保存成驱动包。 |
| A 下载失败 | 在 B 测同一固定资产。B 能下载就缓存完整文件、校验，再经已有 SFTP 传到 A。A 再算 SHA256 与 B 比对，成功后才解包。B 与 A 在同一局域网仍可能使用不同出口或代理。 |
| B 下载失败 | 若 A 对该资产可达，直接在 A 获取和校验，按需传回 B；两端都失败则复用已经配置且获准使用的代理、可信缓存或离线包。有可行路径就继续，无需让用户反复更换网络。 |
| 两端和已有备用路径都不可用 | 只把依赖该资产的操作记为待下载，继续其余可做的检查。一次向用户提供资产名、官方来源和需要放置的位置。经第三方转存的包须用独立可信的发布方摘要或签名验证后再执行。 |

大文件使用临时文件并限制重试。支持断点续传时，先确认仍是同一资产，并核对服务端接受续传；完整落盘、大小和校验通过后再改为正式文件名。有官方摘要时同时比对官方值，两端哈希相同只说明传输一致。遇证书校验失败，保留 TLS 验证并换已获准的可用路径。日志分别写明在哪台电脑探测、是否收到完整文件及校验结果。在线恢复安装仍需 A 在恢复环境中访问 Apple 服务，B 代下 GitHub 文件解决的是工具和驱动的传输。

官方资产 API 的响应与摘要字段见 [GitHub Release assets](https://docs.github.com/en/rest/releases/assets)。

## 锁定版本与来源

下载、EFI 组装、文件校验和已经授权的写盘连续执行，用户无需每下载一个组件回复“继续”。仅在需要插 U 盘、确认具体清空目标或准备重启时交接；默认三项短输出，详细版本与哈希留在日志。

按硬件报告选择 macOS 和 OC 组合。在任务目录记录每项 URL、标签／提交、下载时间、SHA256、用途、适配范围和校验证据。优先官方稳定发布；实验构建注明原因。镜像站只解决传输问题，不能替代原作者来源核对。不把“最新”作为固定版本号，也不擅自升级安装中已锁定的组件。

OpenCore 程序、OpenRuntime、Sample.plist、Configuration 文档和 ocvalidate 来自**同一个发布包**。恢复镜像从 Apple 服务获取，可使用该 OC 包中的 macrecovery；先看当前 `--help` 与文档再选 board-id／参数。不要凭记忆复制“latest”等于 Sequoia 的老命令。下载后验证实际镜像版本与对应 chunklist；镜像版本和最终联网安装的完整系统版本分别记录。[Windows 制作介质](https://dortania.github.io/OpenCore-Install-Guide/installer-guide/windows-install.html)

恢复镜像是安装恢复环境，不是完整离线系统镜像，也不是 BIOS 固件。恢复环境联网必须可用，否则先准备可用网卡／驱动或明确的离线安装方案。若用户指定精确小版本但 Apple 恢复服务器不提供，说明实际可取得版本，不静默替换。

## ACPI：默认不增加重启

固定优先级：复用本任务已验证的 A 原始表 → 在 A 的 Windows 中自动准备 Python 并采集 → 默认路线经诊断仍失败时让用户选择备用路线。不能把“A 没有 Python”直接改成“先重启采集”，也不能为追求不安装工具而增加人工操作。已有原作者原生导出工具且能验证输出时，可直接使用，仍然不用 Python 或重启。

| 路线 | Agent 做什么 | 用户做什么 |
|---|---|---|
| 默认：Windows + Python | 复用兼容解释器；缺少时安装官方用户级 Python，准备锁定的 SSDTTime／ACPICA，在 A 导出后传回 B | 通常无需操作；在首次短提示中说明可选免 Python 路线，不另开一轮安装确认 |
| 可选：免 Python 的 SysReport | 准备同版本 OpenCore DEBUG 诊断配置，开启 SysReport，取回真实表后再制作安装配置 | 用户选择后，额外启动到 OC 菜单并回 Windows；采集时不进入 macOS 恢复 |

默认路线的连续动作：

1. 用当前已验证的 SSH 连接确认 A 身份；在 A 实际执行 Python 版本／标准库检查，不能把商店别名当成解释器。已存在兼容版本不重复安装。
2. 缺少时由 Agent 从 Python 官方渠道获取与所选工具兼容的 Windows 安装包，锁定版本和下载证据，校验签名／发布方提供的校验值。默认用户级安装，使用完整解释器路径；不要改系统 PATH、文件关联或覆盖现有 Python。传统 EXE 安装器可使用其实际支持的 `/quiet`、`InstallAllUsers=0`、`PrependPath=0`、`Include_launcher=0`、`Include_test=0` 和独立 `TargetDir`；先核对该安装器帮助，安装后真实运行验证。不能把安装器参数直接用于 MSIX／安装管理器。[Python Windows 安装说明](https://docs.python.org/3/using/windows.html)
3. 锁定原作者 SSDTTime 提交及其实际依赖，工具放进任务目录。通过 SSH 调用解释器完整路径与 `SSDTTime.py`；不要假设 `.bat` 的交互式自动下载器适合无人值守，也不要编造工具没有的 CLI。需要交互时根据锁定版本的实际菜单／源代码传入输入；使用库调用也先核对实际接口。SSDTTime 的 Windows 导出会使用 ACPICA 工具，Python 本身不是唯一能够读取 ACPI 的途径。[SSDTTime](https://github.com/corpnewt/SSDTTime)、[Windows 导出实现](https://github.com/corpnewt/SSDTTime/blob/master/Scripts/dsdt.py)
4. 必须在 **A** 导出，B 负责下载、分析和保存；在 B 执行导出得到的是 B 的表。保存 A 身份、BIOS 版本、工具版本、退出码、时间及原始输出。取回 DSDT 和可取得的 SSDT 原始二进制，保留未修改副本；检查实际签名、长度、校验和及哈希，并用锁定的 iasl 分析／反编译。缺表、无法解析或依赖不全时停止安装交接，处理具体原因，不以“命令已运行”算完成。
5. 按本机命名空间和硬件生成／选取确有必要的补丁，记录每个启用补丁的原始表依据与用途。不是所有机器都需要相同 SSDT，也不要把整份别机 DSDT 注入。ACPI 表完整仍不能证明 Booter／UEFI／CPU 配置正确：单独审核实际 config、固件内存映射依据与适用的 CPU 设置。

遇到权限、依赖、下载／证书或导出错误，保留日志，在 Windows 中做针对性恢复；不关闭 TLS 校验、不循环盲试、不擅自切换重启路线。用户明确不装 Python或默认路线无法完成时，用一句话给出 SysReport 的操作代价，让用户选择。用户已经选择则直接执行，不重复确认。

SysReport 路线是**采集启动**：使用所选 OC 版本文档要求的 DEBUG 构建，核对 `Misc → Debug → SysReport`、可写输出位置和日志，设置显示启动菜单并关闭自动倒计时（`ShowPicker=true`、`Timeout=0`，以该版本文档为准）。交接明确“停在 OC 菜单，不选 macOS；随后从主板 Windows Boot Manager 回 Windows”。确认导出文件实际存在并有效后，再组装安装 EFI；仅开启选项或看到菜单不能算采集成功。保留 Windows 引导和 U 盘备份，不覆盖硬盘 ESP 来采集。[OpenCore 配置文档](https://github.com/acidanthera/OpenCorePkg/blob/master/Docs/Configuration.tex)

## 避免本次实测中出现的三类返工

**按命名空间适配，不按示例猜路径。** 在 DSDT 与相关 SSDT 中核对真实对象、完整父路径、`_HID`／`_CID`、`_STA` 及 `_OSI` 条件。`PCI0` 和 `PC00` 不可互换；样例 `External` 或 `Scope` 指向不存在的对象时，编译成功仍不等于补丁能工作。记录补丁引用的已有对象与主动创建的新对象，分别说明依据。EC／USBX、CPU plugin、RTC／AWAC 各自判断，不把本例的补丁清单变成所有机器的模板。搜不到一次字符串不等于设备不存在：同时检查 EisaId／字符串表示、关联 SSDT 与条件状态。RTC 和 AWAC 可能由同一状态字段互斥启用；依据实际逻辑决定是否需要修复，不直接宣布“缺 RTC”。分析与编译日志保存在 assessment 引用的证据中；控制器的文件检查不会理解这些 ASL 语义。

**库调用也可能有交互。** SSDTTime 某些生成方法会要求选表／确认，不能把“是 Python 方法”当成无交互 API。先检查锁定源码与实际提示，用有边界的子进程试运行：默认墙钟不超过 120 秒、合并日志不超过 4 MiB；以流方式计数并在上限到达时停止自己启动的进程及子进程。进程树必须绑定本次 PID，不杀所有 python／sshd。若提示不断重复、stdin EOF 或日志持续增长，立即停止并记为失败，不无限等待或继续后台写盘。工具明确报告正常长操作时才按新证据调整上限。随后准备确定的输入或已验证的非交互调用；需要手工 ASL 时仍按原始表核对、编译、复查，不能把工具失败当作跳过验收的理由。

**在新版本目录构建。** 默认创建未占用的 `staging/efi/<变体>-<唯一编号>`，从已锁定组件中只复制需要的内容；保留上一版和已验收证据，避免先复制所有文件再批量删除。编译、ocvalidate 和文件引用通过后，再按已有授权核对 U 盘身份、备份并部署。不要反复清空 staging、任务目录或 U 盘来重试，也不要覆盖被旧验收引用的证据文件。Agent 应遵守自身工具的审批机制，不通过改调用形式绕过提示；真实目标与授权未变时不自行增加额外的重复确认。

## 03 的程序验收清单

`review` 的 `acpi_tables` 检查必须为 `pass`，并增加 `manifest` 字段，值为任务目录内的相对路径，例如 `inventory/acpi/collection.json`。该清单采用下面的结构；所有 SHA256、UUID、路径和分析均由实际采集生成，不能把示例当证据。

```json
{
  "schema": "acpi-evidence-v1",
  "machine_uuid": "实际 A 的 UUID，与当前任务相符",
  "method": "windows-python",
  "capture_log": {"path": "evidence/acpi-capture.txt", "sha256": "实际 SHA256"},
  "tables": [{"path": "inventory/acpi/DSDT.aml", "sha256": "实际 SHA256"}],
  "config": {"path": "staging/EFI/OC/config.plist", "sha256": "实际 SHA256"},
  "assessment": {"path": "evidence/acpi-assessment.md", "sha256": "实际 SHA256"},
  "patches": [{
    "path": "staging/EFI/OC/ACPI/SSDT-EXAMPLE.aml",
    "sha256": "实际 SHA256",
    "based_on": ["inventory/acpi/DSDT.aml"],
    "reason": "实际本机设备路径、补丁用途及依据"
  }]
}
```

`tables` 列出实际 DSDT／SSDT 原始文件，至少有 DSDT；其他原始表同样保留，但不塞进这个专用于 AML 表的列表。`patches` 必须与当前 config 中全部启用的 `ACPI → Add` 文件一致，并关联实际原始表。经分析确实不需要 Add 时可为空，但须提供 `no_add_reason` 与完整分析；不能为了越过检查编造“无需补丁”。`method` 另可取 `windows-native` 或 `opencore-sysreport`；后者还要有 `user_choice` 文件路径与 SHA256，记录用户选择。`firmware_config_review` 单独引用固件／Booter／CPU 判断证据。

控制器检查实际文件内容、哈希、表头／长度／校验和、目标字段、当前配置和启用补丁的一致性。清单及文件纳入后续完整性检查；修改 EFI 后必须重新评估并生成匹配清单。程序不判断任意分析文字是否真实，也无法替代 A 端采集来源的核对或实际启动测试。全部要求仍受阶段合同和真实授权约束。

阶段 03 未通过时，下载、备份以及已授权的 U 盘准备可继续，但不能提示“选择 macOS 恢复环境开始安装”。`ocvalidate` 通过不等于 ACPI、固件或启动已验证。控制器只能阻止其自身阶段推进，Agent 不得绕过它直接安排安装启动。

首次试启动还必须有可取回的诊断日志：默认 `Misc → Debug → Target=67`（启用日志、屏幕与文件）和 `AppleDebug=true`，核对 U 盘可写、空余空间、构建与文件位置，重启回来读取实际日志。控制器检查 Target 的日志启用／文件位和 AppleDebug；`Target=3` 只有屏幕输出，会被 `EFI_DIAGNOSTICS_INVALID` 拒绝。这只是启动前配置检查，不保证固件一定写出日志；没有日志时处理写入原因，不把缺失当成功。SysReport 仍须 DEBUG 构建；REL 加开启选项不生效。初次排障默认使用同版本 DEBUG，稳定后再评估关闭诊断。选项语义以该 OC 版本官方文档为准。

## EFI 组装

先展示 [1401 首选、RapidEFI 备用与路线选择](10-existing-solutions.md)，用户选好后通过 `choose-efi` 登记，再执行对应的来源登记。使用 RapidEFI 时，有桌面工具就自动完成可见 GUI 操作；B 上生成时导入 A 的资料。默认从实际运行账户的桌面或成功提示路径取回原始产物，不固定去 C 盘根目录找。03 的阶段报告顶层填写 `source_plan`，原始配置与修改后的配置分别保存。1401 下载失败先按 [网络与镜像检查](10-existing-solutions.md) 处理。全部构建与写后检查通过后，按 [安装能力告知](13-install-expectations.md) 给用户说明后置驱动及当前限制，登记 `installation_expectations` 后再交付安装步骤。

先读 [EFI 固定决策流程](09-efi-diagnostics.md)。本轮按已登记的 1／2／3／4 路线（内部 d/a/b/c）选择起点，保留同机同阶段成功基线作对照。未指定路线的旧任务与后续故障仍先找适用基线，再查生成工具和官方模板。不能把其他机器的 EFI 当作本机已验证基线，也不能把用户明确选的路线静默换成另一条。原版基线对照和添加 DEBUG／日志的诊断变体须分别记录。

前三种路线均已证实不可用、完成回退记录且用户选择 4（内部 c）时，从目标版本 Sample.plist 和 X64 目录开始，按硬件分支建立 EFI。RapidEFI 等生成结果同样须审查；SSH 启动看不见的 GUI 不算生成成功。

**安装 EFI 默认展开辅助条目。** 生成器原始产物归档后，Agent 在本轮测试副本中把 `Misc → Boot → HideAuxiliary` 设为布尔值 **false**（不能是字符串 `"false"`），再执行校验、写盘和实际回读。四条路线一致；保留原始副本便于对照。阶段 03 验收会检查该值，仍隐藏、缺失或类型错误时返回 `EFI_PICKER_INVALID`。升级时已完成的安装阶段不倒退。

按 [启动交接](05-boot-handoff.md)核对实际 PickerMode、OpenCanopy 与资源文件，保留工具原有的文字／图形外观；不能以菜单外观判定 OC 版本。人类指引补一句兜底：**“如果开机只看到 Windows，按空格展开隐藏项。”** 若出现这种情况，回 Windows 后核对实际启动的是否是刚写好的配置。

按需要加入文件：必要 ACPI、VirtualSMC、Lilu 及实际需要的插件、网络驱动、USB 映射等；遵循依赖顺序。不要为了“通用”加载所有网卡、全部显卡补丁和大量来源不明 SSDT。具体设置以原作者相应系统版本说明为准，未知参数先查证。

SMBIOS 选择与身份生成按本机路线完成。保留 Windows 时，BIOS 的 Secure Boot 与 OC 的 SecureBootModel 是两种设置；不能互相混淆。显卡驱动要求改变 SIP／AMFI 等安全设置时，逐项说明并按该驱动当前文档操作，不能把案例中的关闭参数作为默认值。

需要先进入桌面再安装 GPU 驱动的方案，维护独立阶段：

1. `install`：用于恢复／首次安装的最小可启动配置。
2. `prepare-driver`：确有必要时应用驱动安装前提，重启验证。
3. `runtime`：驱动已安装并验证后启用的完整配置。

三者保存清晰文件清单与差异。禁止把运行期强依赖尚未安装驱动的配置提前放进首次启动介质。

## 校验

按 [09 的固定命令](09-efi-diagnostics.md) 生成 `efi_audit.py` 静态报告，记录启用／禁用／条件项及基线差异。不要仅凭目录中有 kext 判断它被启用，不从偶然二进制字符串猜 OC 版本。报告和审查说明加入 `firmware_config_review` 的证据。

在 B 可运行 `python scripts/agentkit.py check-efi --root <EFI目录>` 做引用与路径检查，随后运行**同版本** ocvalidate。配套检查工具不是 ocvalidate 替代品，也不能证明能启动。核对启用的 ACPI、驱动、kext、Info.plist 与执行文件均存在；无版本冲突或重复注入；禁用项缺文件不应误报为启动失败。

核对 ACPI 补丁是否匹配当前表、USB 地图是否对应本机、CPU 核心补丁是否对应实际硬件。任何例外要有依据并记录。ocvalidate 不检查真实硬件兼容性，也不保证补丁有效。

## U 盘目录与复制

在已确认的 FAT32 安装分区根目录，常规 X64 恢复介质布局为：

```text
EFI/
  BOOT/BOOTx64.efi
  OC/OpenCore.efi
  OC/config.plist
  OC/ACPI/...
  OC/Drivers/...
  OC/Kexts/...
com.apple.recovery.boot/
  BaseSystem.dmg + BaseSystem.chunklist
  或 RecoveryImage.dmg + RecoveryImage.chunklist
```

文件名称与配对应来自实际下载结果，不把两套文件混合。避免 EFI/EFI/OC 的多嵌套错误。若采用别的安装介质路线，说明差异并按该路线验证。

传输用 SFTP／可靠复制；网络中断后先确认部分文件，不能把“上传开始”当作完成。写入后从 A 上的 U 盘回读哈希，与 staging 比对；检查实际文件系统与空间，保存最终清单。准备日志输出和可回到 Windows 的启动办法，之后再进入 BIOS 交接。
