﻿& {
    $ErrorActionPreference = 'Stop'
    $BIPv4 = @() # Agent 在发给用户前填入 B 的实际 IPv4；获取不到时保持空。
    $step = '权限检查'
    $report = [ordered]@{schema='ssh-handoff-v1';status='failed';stage='00'}
    function Test-IPv4Subnet([string]$A, [string]$B, [int]$Prefix) {
        if ($Prefix -lt 0 -or $Prefix -gt 32) { throw 'IPv4 前缀长度无效。' }
        $aa = [Net.IPAddress]::Parse($A).GetAddressBytes()
        $bb = [Net.IPAddress]::Parse($B).GetAddressBytes()
        if ($aa.Length -ne 4 -or $bb.Length -ne 4) { throw '网段比较需要 IPv4 地址。' }
        for ($bit = 0; $bit -lt $Prefix; $bit++) {
            $index = [int][Math]::Floor($bit / 8)
            $mask = 1 -shl (7 - ($bit % 8))
            if (($aa[$index] -band $mask) -ne ($bb[$index] -band $mask)) { return $false }
        }
        return $true
    }
    Write-Host '00 准备工作和远程接入　正在为这台待安装的电脑（A）开启并检查远程登录，请稍候。'
    try {
        $isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        if (-not $isAdmin) { throw '请在 A 电脑以管理员身份打开 Windows PowerShell，再粘贴整块代码。' }

        $step = '安装服务器'
        $serverSource = 'existing'
        if (-not (Get-Service -Name sshd -ErrorAction SilentlyContinue)) {
            $serverSource = 'installed-now'
            $cap = Get-WindowsCapability -Online -Name 'OpenSSH.Server~~~~0.0.1.0'
            if ($cap.State -eq 'NotPresent') {
                $setup = Add-WindowsCapability -Online -Name 'OpenSSH.Server~~~~0.0.1.0'
                if ($setup.RestartNeeded) {
                    $report.status = 'restart-required'
                    throw '组件要求重启；重启后再运行这整块代码。'
                }
                $cap = Get-WindowsCapability -Online -Name 'OpenSSH.Server~~~~0.0.1.0'
            }
            if ($cap.State -ne 'Installed') { throw '组件状态不是 Installed，请把完整输出发给 Agent。' }
        }
        if (-not (Get-Service -Name sshd -ErrorAction SilentlyContinue)) {
            throw '组件已安装但没有 sshd 服务，请把完整输出发给 Agent。'
        }

        $step = '启动并检查监听'
        Set-Service -Name sshd -StartupType Automatic
        if ((Get-Service -Name sshd).Status -ne 'Running') { Start-Service -Name sshd }
        $listen = @()
        for ($attempt = 0; $attempt -lt 15; $attempt++) {
            $svc = Get-CimInstance -ClassName Win32_Service -Filter "Name='sshd'"
            $lan = @(Get-NetIPAddress -AddressFamily IPv4 | Where-Object {
                $_.AddressState -eq 'Preferred' -and $_.IPAddress -notmatch '^(127\.|169\.254\.)'
            })
            $listen = @(Get-NetTCPConnection -State Listen -LocalPort 22 -ErrorAction SilentlyContinue | Where-Object {
                $_.OwningProcess -eq $svc.ProcessId -and
                ($_.LocalAddress -in @('0.0.0.0', '::') -or $_.LocalAddress -in $lan.IPAddress)
            })
            if ($svc.State -eq 'Running' -and $svc.StartMode -eq 'Auto' -and $listen.Count -gt 0) { break }
            Start-Sleep -Seconds 1
        }
        if ($svc.State -ne 'Running' -or $svc.StartMode -ne 'Auto' -or $listen.Count -eq 0) {
            throw 'sshd 尚未以自动服务监听可远程访问的 TCP 22。请把输出发给 Agent，检查服务日志、Port/ListenAddress 和端口占用；不自动覆盖已有配置。'
        }

        if ($lan.Count -eq 0) { throw '没有可用的网卡 IPv4，请先检查网线、Wi-Fi 或 DHCP，再重新执行。' }
        $step = '配置防火墙'
        $ruleName = 'Hackintosh-Skill-SSH-In-TCP'
        # A service-specific rule cannot match when sshd has SERVICE_SID_TYPE_NONE.
        # Explicit Any also clears the incompatible binding on rules from older releases.
        $ruleOptions = @{
            Name=$ruleName; PolicyStore='PersistentStore'; Enabled='True'
            Direction='Inbound'; Action='Allow'; Profile='Any'; Protocol='TCP'
            LocalPort=22; RemoteAddress='LocalSubnet'; Service='Any'
        }
        if (Get-NetFirewallRule -PolicyStore PersistentStore -Name $ruleName -ErrorAction SilentlyContinue) {
            Set-NetFirewallRule @ruleOptions
        } else {
            New-NetFirewallRule @ruleOptions -DisplayName 'Hackintosh Skill - Windows SSH (LAN)' | Out-Null
        }
        $rule = Get-NetFirewallRule -PolicyStore ActiveStore -Name $ruleName
        $port = Get-NetFirewallPortFilter -AssociatedNetFirewallRule $rule
        $address = Get-NetFirewallAddressFilter -AssociatedNetFirewallRule $rule
        $serviceFilter = Get-NetFirewallServiceFilter -AssociatedNetFirewallRule $rule
        if ($rule.Enabled -ne 'True' -or $rule.Direction -ne 'Inbound' -or $rule.Action -ne 'Allow' -or
            $rule.Profile -ne 'Any' -or $port.Protocol -notin @('TCP','6') -or
            $port.LocalPort -ne '22' -or $address.RemoteAddress -notcontains 'LocalSubnet' -or
            $serviceFilter.Service -ne 'Any') {
            throw '防火墙规则核验未通过，请把输出发给 Agent；不要关闭整个防火墙。'
        }


        $step = '生成连接信息'
        $username = (whoami.exe | Out-String).Trim()
        if (-not $username) { throw '未能取得当前账户名。' }
        $keygen = Join-Path $env:WINDIR 'System32\OpenSSH\ssh-keygen.exe'
        if (-not (Test-Path -LiteralPath $keygen)) { throw '未找到系统 ssh-keygen；需要 Agent 核对当前 OpenSSH 安装来源。' }
        $keyDirectory = Join-Path $env:ProgramData 'ssh'
        $fingerprints = @()
        foreach ($keyFile in @(Get-ChildItem -LiteralPath $keyDirectory -Filter 'ssh_host_*_key.pub' -File)) {
            $keyText = (& $keygen -l -E sha256 -f $keyFile.FullName | Out-String).Trim()
            if ($LASTEXITCODE -ne 0) {
                throw ('ssh-keygen 读取公钥失败，退出码：' + $LASTEXITCODE + '；文件：' + $keyFile.Name)
            }
            if ($keyText -notmatch '(SHA256:[A-Za-z0-9+/]+)\s+.*[(]([^)]+)[)]$') {
                throw ('主机公钥指纹输出格式未识别：' + $keyText)
            }
            $fingerprints += [ordered]@{algorithm=$Matches[2];sha256=$Matches[1]}
        }
        if ($fingerprints.Count -eq 0) { throw '默认目录没有主机公钥；需要 Agent 检查服务配置与 HostKey 路径。' }
        $matching = @()
        foreach ($a in $lan) {
            foreach ($b in $BIPv4) {
                if (Test-IPv4Subnet $a.IPAddress $b $a.PrefixLength) { $matching += $a.IPAddress; break }
            }
        }
        $sameSubnet = if ($BIPv4.Count -eq 0) { $null } else { $matching.Count -gt 0 }
        $report.status = 'local-ready'
        $report.host = $env:COMPUTERNAME
        $report.user = $username
        $report.port = 22
        $report.ipv4 = @($lan | ForEach-Object { [ordered]@{ip=$_.IPAddress;prefix=$_.PrefixLength;interface=$_.InterfaceAlias} })
        $report.host_keys = $fingerprints
        $report.checks = [ordered]@{server=$serverSource;service='Running';startup='Auto';listener='sshd:22';firewall='LocalSubnet/AnyProfile'}
        $report.network = [ordered]@{b_ipv4=@($BIPv4);same_subnet_from_a=$sameSubnet;matching_a=@($matching);connectivity='pending-b-test'}
    } catch {
        $report.failed_step = $step
        $report.error = $_.Exception.Message
    }
    if ($report.status -eq 'local-ready') {
        Write-Host 'A 上的远程登录已准备好。接下来由 B 上的助手试着连进来。'
        Write-Host '遇到 360、火绒或电脑管家拦截时，请放行 OpenSSH（TCP 22）。如选择临时关闭网络防护，验证后恢复。'
        Write-Host '请复制下面两行，粘贴到 B 上和助手的聊天框。按第一行提示填写后一起发送。想装的 macOS 版本也可一起写，不清楚就写“未定”。'
    } elseif ($report.status -eq 'restart-required') {
        Write-Host 'Windows 需要重启才能继续。请保存文件，重启 A，再用管理员身份运行刚才的整块代码。'
        Write-Host '如果重启后仍看到这条提示，把下面这行结果发到 B 上和助手的聊天框。'
    } else {
        Write-Host ('A 上的远程登录还没有准备好。停在“' + $step + '”。')
        Write-Host '请复制下面一整行，发到 B 上和助手的聊天框，助手会依据错误提示继续排查。'
    }
    if ($report.status -eq 'local-ready') {
        Write-Output 'A_LOGIN_CREDENTIAL: 请将此字段替换为 A 电脑的登录密码，或 B 电脑上包含登录密码的文件完整路径；已提供可填“已提供”'
    }
    Write-Output ('SSH_HANDOFF_V1 ' + ($report | ConvertTo-Json -Depth 6 -Compress))
}
